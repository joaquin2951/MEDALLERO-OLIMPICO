#ifndef PAISES_H

void imprimirPais(int indice);
void listarPaises();

#endif
