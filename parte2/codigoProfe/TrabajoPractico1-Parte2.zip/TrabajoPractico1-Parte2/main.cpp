#include<iostream>
#include "paises.h"
#include "deportes.h"
using namespace std;

int main (int argc, char *argv[]) {
	
cout<<"Lista de paises"<<endl;
listarPaises();
cout<<endl<<"Lista de deportes COLECTIVOS"<<endl;
mostrarDeportesColectivos();
cout<<endl<<"Lista de deportes INDIVIDUALES"<<endl;
mostrarDeportesIndividuales();
cout<<endl<<"Lista de deportes"<<endl;
mostrarDeportes();
	return 0;
}

